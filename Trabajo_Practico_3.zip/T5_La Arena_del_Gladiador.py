vida_del_gladiador = 100 
vida_del_enemigo = 100 
pociones_de_vida = 3 
ataque_pesado = 15 
dano_del_enemigo = 12 
turno_gladiador = True 

print(" ---- BIENVENIDO A LA ARENA ---- ")
nombre_gladiador = input("Ingrese el nombre de su gladiador: ").strip().capitalize()
while not nombre_gladiador.isalpha():
    print("Vuelva a intentar, solo letras")
    nombre_gladiador = input("Ingrese el nombre de su gladiador: ").strip().capitalize()
print()
print(" === INICIO DEL COMBATE === ")
print()
while vida_del_gladiador > 0 and vida_del_enemigo > 0:
    print(f"- {nombre_gladiador} - HP : {vida_del_gladiador} vs Enemigo - HP : {vida_del_enemigo} - Pociones de vida: {pociones_de_vida}")
    print("""Elige a accion:
        1. Ataque pesado
        2. Rafaga veloz
        3. Curar
        """)
    opcion = input("Opción: ").strip()
    while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 3:
        print("Error. Por favor ingrese 1, 2 o 3.")
        opcion = input("Opción: ").strip()
    if opcion == "1":
        if vida_del_enemigo < 20:
            dano_final = ataque_pesado * 1.5
            print(f"Has atacado al enemigo, puntos de daño: {dano_final}")
        else:
            dano_final = ataque_pesado
            print(f"Has atacado al enemigo, puntos de daño: {dano_final}")
        vida_del_enemigo -= dano_final
    elif opcion == "2":
        print("Rafaga de golpes")
        for _ in range(3):
            vida_del_enemigo -= 5
            print("Golpe exitoso, puntos de daño: 5")
    elif opcion == "3":
        if pociones_de_vida > 0:
            vida_del_gladiador += 20
            pociones_de_vida -= 1
            if vida_del_gladiador > 100:
                vida_del_gladiador = 100
            print(f" Te has curado, HP:{vida_del_gladiador} - Pociones restantes: {pociones_de_vida}")
        else:
            print("No te quedan mas pociones de vida.")

        if vida_del_enemigo > 0:
            vida_del_gladiador -= dano_del_enemigo
            print(f"El enemigo te ha atacado, puntos de daño: {dano_del_enemigo}")
        if vida_del_gladiador > 0 and vida_del_enemigo > 0:
            print(" ==== NUEVO TURNO ====")
    print()        
    print(" ==== FIN DEL COMBATE ====")
    print()
if vida_del_gladiador > 0:
    print(f"Victoria {nombre_gladiador} has ganado el combate!")
else:
    print("HAS PERDIDO! El enemigo ha ganado el combate.")