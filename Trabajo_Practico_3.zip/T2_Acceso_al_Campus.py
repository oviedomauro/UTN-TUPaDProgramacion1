usuario = "alumno"
clave = "python123"
intentos = 3
nueva_clave = clave
while (intentos >= 1):

        usuario_cliente = input("Ingrese sus usuario: ").strip()
        clave_cliente = input("Ingrese su clave: ")
        if usuario == usuario_cliente and clave == clave_cliente:
            print("Ingreso exisoto, bienvenido al menu")
            while True:
                print("==========================")
                print("Menu")
                print("==========================")
                print("1. Ver estado de inscripción")
                print("2. Cambiar clave")
                print("3. Mostrar mensaje motivacional")
                print("4. Salir")

                while True:

                    opcion = input("Elija una opcion: ")

                    if opcion.isdigit():
                        if opcion == "1":
                            print("==========================")
                            print("Estado de inscripción:  Inscripto")
                            print("==========================")

                        
                        elif opcion == "2":
                            while True:
                                cambiar_clave = input("Ingrese su nueva clave: ")

                                if len(cambiar_clave) < 6:
                                    print("Error: minimo 6 caracteres.")
                                else:
                                    confirmar_clave = input("Confirme la clave: ")

                                    if cambiar_clave == confirmar_clave:
                                        print("==========================")
                                        print("La clave se cambio correctamente.")
                                        print("==========================")
                                        clave = cambiar_clave
                                        break
                                    else:
                                        print("Error la clave no coincide, vuelva a intertarlo.")              

                        elif opcion == "3":
                            print("==========================")
                            print("No te rindas, no importa que tan complicado sea para todo hay solucion, vos podes rey!")
                            print("==========================")

                        elif opcion == "4":
                            print("Saliendo.")
                            break
                        else:
                            print("==========================")
                            print("Intente de nuevo")
                    else:
                        print("==========================")
                        print("Numero invalido")

        else:
            intentos -= 1
            print("Su usuario o clave es incorrecta.")
            if intentos == 0:
                print("=================================================")
                print("Excedió el limite de intentos, cuenta bloqueada.")
                print("=================================================")