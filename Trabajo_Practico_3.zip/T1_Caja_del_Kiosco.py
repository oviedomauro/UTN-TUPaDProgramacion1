
total_sin_desc = 0
total_con_desc = 0
while True:

    nombre = input("Cliente ingrese su nombre: ")
    if nombre.isalpha():
        print(f"Bienvenido {nombre} !!")
        break
    else:
        print("Error, vuelva a intentar solo con letras, sin espacio su nombre.")
    

while True:
        cantidad_productos = (input("Ingrese cuantos productos va a comprar: "))
        if cantidad_productos.isdigit() and cantidad_productos != ""  and int(cantidad_productos) > 0:
            print(f"Se registro {cantidad_productos} productos.")
            cantidad_productos = int(cantidad_productos)
            break
        else:
        
            print("Vuelva a intentar con numeros positivos.")

for i in range(cantidad_productos):
    while True:
        precio_produc = input(f"Ingrese el precio del producto {i+1}: ")
        if precio_produc.replace(".", "", 1).isdigit() and precio_produc != ""  and float(precio_produc) > 0:
            print(f"El precio del producto {i+1} es: ${precio_produc} ")
            precio_produc = float(precio_produc)
            total_sin_desc += precio_produc
            break
        else:
            print("Por favor ingrese solo numeros.")

    while True:
        preguntar_desc = input(f"Tiene descuento para el producto {i+1}(s/n): ")


        if preguntar_desc == "s" or preguntar_desc == "S" or preguntar_desc == "n" or preguntar_desc == "N":
            if preguntar_desc == "s" or preguntar_desc == "S":
                print("----------------------------------")
                print(f"Descuento aplicado en el producto {i+1}")
                print("----------------------------------")
                precio_con_descuento = precio_produc -(precio_produc *(10 /100))
                total_con_desc += precio_con_descuento
            else:
                print("----------------------------------")
                print("Sin descuento.")
                print("----------------------------------")
            break
        else:
            print("Por favor vuelva a intentar, solo(s/n)")

ahorro = total_sin_desc - total_con_desc
promedio = total_con_desc / cantidad_productos

print("=======================================")
print(f"Cliente: {nombre}")
print(f"Producto {i+1} - Precio: ${precio_produc} - Descuento(s/n): {preguntar_desc}")
print(f"Total sin descuento: ${total_sin_desc}")
print(f"Total con descuento: ${total_con_desc}")
print(f"Ahorro: ${ahorro:.2f}")
print(f"Promedio: ${promedio:.2f}")
print("=======================================")