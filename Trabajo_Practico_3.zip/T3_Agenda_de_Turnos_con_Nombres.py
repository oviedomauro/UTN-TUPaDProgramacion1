lunes1 = ""
lunes2 = ""
lunes3 = ""
lunes4 = ""

martes1 = ""
martes2 = ""
martes3 = ""

nombre_operador =input("Ingrese su nombre: ").strip()
while not nombre_operador.isalpha():
    print("Solo letras, vuelva a intentar:")
    nombre_operador =input("Ingrese su nombre: ").strip()

print(f"Bienvenido {nombre_operador}")
while True:
    print("================================================")
    print("                    MENU                        ")
    print("================================================")
    print("1. Reservar turno")
    print("2. Cancelar turno (por nombre)")
    print("3. Ver agenda del día")
    print("4. Ver resumen general")
    print("5. Cerrar sistema")
    print("================================================")
        
    opcion = input("Seleccione una opcion(1-5): ").strip()
    while not opcion.isdigit() or not (1 <= int(opcion) <= 5):
        print("---------------------------------------------")
        print("Opcion invalidad, elija un numero del 1 al 5.")
        print("---------------------------------------------")
        opcion = input("Seleccione una opcion(1-5): ").strip()
    opcion = int(opcion)
        
    if opcion == 1:
        dia = input("""Elige dia para el turno:
                    Lunes (1)
                    Martes(2)
                    :""").strip()
        while dia != "1" and dia !="2":
            print("Por favor vuelva a intentar(1 o 2)")
            dia = input("""Elige dia para el turno:
                    Lunes (1)
                    Martes (2)
                    :""").strip()
        nombre_paciente = input("Ingrese el nombre del paciente: ").strip()

        while not nombre_paciente.isalpha():
            print("Error, vuelva a intentar, solo letras")
            nombre_paciente = input("Ingrese el nombre del paciente: ").strip()

        if dia == "1":
            if nombre_paciente == lunes1 or nombre_paciente == lunes2 or nombre_paciente == lunes3 or nombre_paciente == lunes4:
                print("El paciente ya tiene un turno registrado")
            else:
                if lunes1 == "":
                    lunes1 = nombre_paciente
                elif lunes2 == "":                                
                    lunes2 = nombre_paciente
                elif lunes3 == "":
                    lunes3 = nombre_paciente
                elif lunes4 == "":
                    lunes4 = nombre_paciente
                else:
                    print("No hay turnos disponibles para el lunes")
        else:
            
            if nombre_paciente == martes1 or nombre_paciente == martes2 or nombre_paciente == martes3:
                print("El paciente ya tiene un turno registrado")
            else:
                if martes1 == "":
                    martes1 = nombre_paciente
                elif martes2 == "":
                    martes2 = nombre_paciente
                elif martes3 == "":
                    martes3 = nombre_paciente
                else:
                    print("No hay turnos disponibles para el martes")

    elif opcion == 2:
        dia =input("""Elige dia para el turno:
                    Lunes (opcion 1)
                    Martes (opcion 2)
                    :""").strip()
            
        while dia != "1" and dia !="2":
            print("Por favor vuelva a intentar(1 o 2)")
            dia = input("""Elige dia para el turno:
                    Lunes (1)
                    Martes (2)
                    :""").strip()
        nombre_paciente = input("Ingrese el nombre del paciente: ").strip()

        while not nombre_paciente.isalpha():
            print("Error, vuelva a intentar, solo letras")
            nombre_paciente = input("Ingrese el nombre del paciente: ").strip()

        if dia == "1":
            if lunes1 == nombre_paciente:
                lunes1 = ""
            elif lunes2 == nombre_paciente:
                lunes2 = ""
            elif lunes3 == nombre_paciente:
                lunes3 = ""
            elif lunes4 == nombre_paciente:
                lunes4 = ""
            else:
                print("Paciente no entrado en la lista del Lunes")
        else:
            if martes1 == nombre_paciente:
                martes1 = ""
            elif martes2 == nombre_paciente:
                martes2 = ""
            elif martes3 == nombre_paciente:
                martes3 = ""
            else:
                print("Paciente no entrado en la lista del Martes")

    elif opcion == 3:
        dia =input("""Elige dia para el turno:
                    Lunes (1)
                    Martes (2)
                    :""").strip()
        while dia != "1" and dia !="2":
            print("Por favor vuelva a intentar(1 o 2)")
            dia = input("""Elige dia para el turno:
                    Lunes (1)
                    Martes (2)
                    :""").strip()
        if dia == "1":
            print("Agenda del Lunes:")
            print(f"Turno 1: {lunes1 if lunes1 != '' else '(Libre)'}")
            print(f"Turno 2: {lunes2 if lunes2 != '' else '(Libre)'}")
            print(f"Turno 3: {lunes3 if lunes3 != '' else '(Libre)'}")
            print(f"Turno 4: {lunes4 if lunes4 != '' else '(Libre)'}")
        else:
            print(f"Turno 1: {martes1 if martes1 != '' else '(Libre)'}")
            print(f"Turno 2: {martes2 if martes2 != '' else '(Libre)'}")                    
            print(f"Turno 3: {martes3 if martes3 != '' else '(Libre)'}")
        
    elif opcion == 4:
        ocupados_lunes = 0
        ocupados_martes = 0

        if lunes1 != "":
            ocupados_lunes += 1
        if lunes2 != "":
            ocupados_lunes += 1
        if lunes3 != "":
            ocupados_lunes += 1
        if lunes4 != "":
            ocupados_lunes += 1

        if martes1 != "":
            ocupados_martes += 1
        if martes2 != "":
            ocupados_martes += 1
        if martes3 != "":
            ocupados_martes += 1

        libres_lunes = 4 - ocupados_lunes
        libres_martes = 3 - ocupados_martes

        print("Resumen general:")
        print(f"Lunes --- Ocupados: {ocupados_lunes} - Disponibles: {libres_lunes}")
        print(f"Martes --- Ocupados: {ocupados_martes} - Disponibles: {libres_martes}")

        if ocupados_lunes > ocupados_martes:
            print("Dia con mas turnos: Lunes")
        elif ocupados_martes > ocupados_lunes:
            print("Dia con mas turnos: Martes")
        else:
            print("Ambos tienen la misma cantidad de turnos")

    elif opcion == 5:
        print("Cerrando sistema.")
        break
