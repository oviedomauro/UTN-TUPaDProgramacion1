energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""
anti_spam = 0

nombre_del_agente = input("Ingrese un nombre: ").strip()
while not nombre_del_agente.isalpha():
    print("Vuelva a intentarlo, solo letras")
    nombre_del_agente = input("Ingrese un nombre: ").strip()

print(f"hola {nombre_del_agente}")

while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3 and not (alarma and tiempo <=3):
    print("====================================")
    print(f"Energia: {energia}%")
    print(f"Tiempo: {tiempo} minutos")
    print(f"Cerraduras abiertas: {cerraduras_abiertas}/3")
    print("====================================")
    print("1. Forzar cerradura (costo: -20 energía, -2 tiempo)")
    print("2. Hackear panel (costo: -10 energía, -3 tiempo)")
    print("3. Descansar (costo: +15 energía (máx 100), -1 tiempo; si alarma ON: -10 energía extra)")
    print("====================================")

    opcion = input("Elija una opcion: ").strip()
    while not opcion.isdigit() or opcion not in ("1", "2", "3"):
        print("Vuelva a intentar, solo numeros")
        opcion = input("Elija una opcion: ").strip()


    if opcion == "1":
        energia -= 20
        tiempo -= 2
        anti_spam += 1

        if anti_spam >= 3:
            print("""no se abrio la cerradura, se trabo la cerradura
                !!!SE ACTIVO LA ALARMA!!!""")
            alarma = True
            anti_spam = 0
            break

        else:
            if energia < 40:
                print("Energia baja(Riesgo de alarma!)")
                print("Elige un numero del 1 al 3 ")
                pedir_num = input("Ingrese numero: ").strip()
                while not pedir_num.isdigit() or pedir_num not in ("1", "2", "3"):
                    print("Error, vuelva a intentar, solo 1, 2 ,3")
                    print("--------------------------------------")
                    print("Elige un numero del 1 al 3 ")
                    pedir_num = input("Ingrese numero: ").strip()
                if pedir_num == "3":
                    print("La alarma empezo a sonar")
                    alarma = True
                else:
                    print("La alarma aun no se a activado")
                    cerraduras_abiertas += 1
                    print(f"Cerradura abierta! ({cerraduras_abiertas}/3)")
            else:
                if not alarma:
                    cerraduras_abiertas += 1
                    print(f"Cerradura abierta! ({cerraduras_abiertas}/3)")
        print("=================================================================")
        print(f"---Energia al: {energia}% - Tiempo restante: {tiempo} minutos---")
        print("=================================================================")
    
    elif opcion == "2":
        energia -= 10
        tiempo -= 3
        anti_spam = 0

        print("Hackeando...")
        print("Espere...")
        print("...")
        letras = "abcdefgh"
        for paso in range(1,5):
            letra = letras[len(codigo_parcial) % len(letras)]
            codigo_parcial = codigo_parcial + letra
            print(f"Paso {paso}/4 - codigo parcial: {codigo_parcial}")
        if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:
            cerraduras_abiertas += 1
            print(f"Hackeo completo, cerradura abierta va ({cerraduras_abiertas}/3)")
        print("=================================================================")
        print(f"---Energia al: {energia}% - Tiempo restante: {tiempo} minutos---")
        print("=================================================================")
            

    elif opcion == "3":
        anti_spam = 0
        energia += 15
        tiempo -= 1
        if alarma:
            energia -= 10
            print("No descanses mucho por que el tiempo se te acaba")
        if energia > 100:
            energia = 100
        print("15% de energia recuperada")
        print("======================================================================")
        print(f"---Energia al: {energia}% - Tiempo restante: {tiempo} minutos---")
        print("======================================================================")

if cerraduras_abiertas == 3:
    print(f"Felicidades agente {nombre_del_agente} lograste ganar!")
elif alarma and tiempo <= 3:
    print(f"Lo siento agente {nombre_del_agente}, se bloqueo el sistema")
elif energia <= 0:
    print(f"Te quedaste sin energia agente {nombre_del_agente}, perdiste")
elif tiempo <= 0:
    print(f"Te quedaste sin tiempo agente {nombre_del_agente}, Perdiste")
print(f"Cerraduras abiertas: {cerraduras_abiertas}/3")
print("Fin de la mision")